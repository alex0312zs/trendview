## 2.0.9（2021-12-01）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. 优化swiper的height支持100%值(仅vue有效)，修复嵌入视频时click事件无法触发的问题
2. 优化tabs组件对list值为空的判断，或者动态变化list时重新计算相关尺寸的问题
3. 优化datetime-picker组件逻辑，让其后续打开的默认值为上一次的选中值，需要通过v-model绑定值才有效
4. 修复upload内嵌在其他组件中，选择图片可能不会换行的问题
## 2.0.8（2021-12-01）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. 修复toast的position参数无效问题
2. 处理input在ios nvue上无法获得焦点的问题
3. avatar-group组件添加extraValue参数，让剩余展示数量可手动控制
4. tabs组件添加keyName参数用于配置从对象中读取的键名
5. 处理text组件名字脱敏默认配置无效的问题
6. 处理picker组件item文本太长换行问题
## 2.0.7（2021-11-30）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. 修复radio和checkbox动态改变v-model无效的问题。
2. 优化form规则validator在微信小程序用法
3. 修复backtop组件mode参数在微信小程序无效的问题
4. 处理Album的previewFullImage属性无效的问题
5. 处理u-datetime-picker组件mode='time'在选择改变时间时，控制台报错的问题
## 2.0.6（2021-11-27）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. 处理tag组件在vue下边框无效的问题。
2. 处理popup组件圆角参数可能无效的问题。
3. 处理tabs组件lineColor参数可能无效的问题。
4. propgress组件在值很小时，显示异常的问题。
## 2.0.5（2021-11-25）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. calendar在vue下显示异常问题。 
2. form组件labelPosition和errorType参数无效的问题
3. input组件inputAlign无效的问题
4. 其他一些修复
## 2.0.4（2021-11-23）
## [点击加群交流反馈：232041042](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

0. input组件缺失@confirm事件，以及subfix和prefix无效问题
1. component.scss文件样式在vue下干扰全局布局问题
2. 修复subsection在vue环境下表现异常的问题
3. tag组件的bgColor等参数无效的问题
4. upload组件不换行的问题
5. 其他的一些修复处理
## 2.0.3（2021-11-16）
## [点击加群交流反馈：1129077272](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. uView2.0已实现全面兼容nvue
2. uView2.0对1.x进行了架构重构，细节和性能都有极大提升
3. 目前uView2.0为公测阶段，相关细节可能会有变动
4. 我们写了一份与1.x的对比指南，详见[对比1.x](https://www.uviewui.com/components/diff1.x.html)
5. 处理modal的confirm回调事件拼写错误问题
6. 处理input组件@input事件参数错误问题
7. 其他一些修复
## 2.0.2（2021-11-16）
## [点击加群交流反馈：1129077272](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. uView2.0已实现全面兼容nvue
2. uView2.0对1.x进行了架构重构，细节和性能都有极大提升
3. 目前uView2.0为公测阶段，相关细节可能会有变动
4. 我们写了一份与1.x的对比指南，详见[对比1.x](https://www.uviewui.com/components/diff1.x.html)
5. 修复input组件formatter参数缺失问题
6. 优化loading-icon组件的scss写法问题，防止不兼容新版本scss
## 2.0.0(2020-11-15)
## [点击加群交流反馈：1129077272](https://jq.qq.com/?_wv=1027&k=KnbeceDU)

# uView2.0重磅发布，利剑出鞘，一统江湖

1. uView2.0已实现全面兼容nvue
2. uView2.0对1.x进行了架构重构，细节和性能都有极大提升
3. 目前uView2.0为公测阶段，相关细节可能会有变动
4. 我们写了一份与1.x的对比指南，详见[对比1.x](https://www.uviewui.com/components/diff1.x.html)
5. 修复input组件formatter参数缺失问题


